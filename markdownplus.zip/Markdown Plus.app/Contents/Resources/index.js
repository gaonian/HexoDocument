alert = confirm = prompt = function(){}; // 禁用js弹窗
console.log = function(message){
    external.print_(message); // 打印到Swift控制台
};

function setMarkdown(content) {
    editor.session.setValue(content, -1);
}

$(function(){
    external.onLoad();
    editor.session.on('change', function() {
        external.onTextChange();
    });
    $('.file-icon').click(function() {
        var name = $(this).data('name');
        external.fileActions_(name);
    });
});

var Vim = ace.require("ace/keyboard/vim").CodeMirror.Vim // vim commands
Vim.defineEx("write", "w", function(cm, input) {
    $('.file-icon[data-name="save"]').click();
});
Vim.defineEx("quit", "q", function(cm, input) {
    if(input.input === 'q') {
        external.quit_(false);
    } else if(input.input === 'q!') {
        external.quit_(true);
    }
});
Vim.defineEx("wq", "wq", function(cm, input) {
    $('.file-icon[data-name="save"]').click();
    external.quit_(false);
});
